# giv-da-proto-ram-nex-tim
This is a batch (*.bat) based virus that eats your ram, kinda like www.YouAreAnIdiot.org but *.bat. On this project I will also find out how to turn it into a *.exe.
All files here are required, so download via the "Go to code"/"Releases" or whatever & hit "download as zip" and extract it.
Video of this on Windows XP can be found here: https://www.youtube.com/watch?v=9btjVgKNqM8.
# The obvious, do's & don't's
Again, do. Not. Steal. My. Work. And. Say. You. Made. It. I'm fine if it credits me or this github, but please, don't steal my work.
# Virus Notes
This will not harm your machine **that bad**. It is made only to use up your ram and cause errors due to lack of ram. I recommand using a Virtual Machine.
Do not place this in "shell:startup", but if you do, it is not my fault for an unuseable machine.
To run the virus, open "LAUNCHER.exe" on x86 and "LAUNCHER (x64).exe" on x64, not "virus.bat" or "error.bat".
I don't know if it works on older versions of Windows, all I know is that it has to support *.txt, *.bat & *.vbs.
# Virus Mirrors
Github (here) is recommanded, Mediafire can be outdated due to multiple links.
https://www.mediafire.com/file/dsvm175rdr0np6i/Harmless.GivDaProtoRamNexTim.zip/file